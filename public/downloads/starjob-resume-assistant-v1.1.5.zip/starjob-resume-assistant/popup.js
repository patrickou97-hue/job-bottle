const STARJOB_HOME = "https://www.starjob.space";
const SMART_MATCH_TIMEOUT_MS = 9_000;
const SMART_MATCH_MAX_FIELDS = 12;
const AI_AUTOFILL_TIMEOUT_MS = 85_000;
const AI_AUTOFILL_BATCH_FIELD_LIMIT = 18;
const AI_AUTOFILL_BATCH_BUDGET = 1_700;
const AI_AUTOFILL_MAX_BATCHES = 100;
const AI_AUTOFILL_MAX_FIELDS = 1_500;
const AI_AUTOFILL_MIN_CONFIDENCE = 0.68;
const PIXEL_STAR_PATTERN = [
  ".....x.....",
  "....xxx....",
  "...xxxxx...",
  "..xx...xx..",
  ".xx.....xx.",
  "xxxxxxxxxxx",
  ".xx.....xx.",
  "..xx...xx..",
  "...xxxxx...",
  "....xxx....",
  ".....x.....",
];
// Hard resume facts already pass the scanner's descriptor, section and control
// compatibility checks at 0.74. Requiring 0.90 here caused plainly labelled
// ATS fields such as school/company to be omitted whenever the label was
// exposed only through a placeholder or a framework wrapper.
const LOCAL_EXACT_MIN_CONFIDENCE = 0.74;
const CONFIRM_WINDOW_MS = 8_000;
const STORAGE_KEYS = ["starjobResumes", "activeResumeId", "fillMode", "lastSyncedAt", "matchToken", "matchTokenExpiresAt", "aiMatchingAvailable", "analysisOnly", "aiOnly", "aiFieldMappings", "aiAutofillOnly", "aiValueMappings", "aiTargetFieldKeys"];

const elements = {
  emptyState: document.querySelector("#emptyState"),
  readyState: document.querySelector("#readyState"),
  resumeSelect: document.querySelector("#resumeSelect"),
  fillButton: document.querySelector("#fillButton"),
  modeHint: document.querySelector("#modeHint"),
  syncMeta: document.querySelector("#syncMeta"),
  resultPanel: document.querySelector("#resultPanel"),
  resultTitle: document.querySelector("#resultTitle"),
  resultText: document.querySelector("#resultText"),
  unmatchedDetails: document.querySelector("#unmatchedDetails"),
  unmatchedList: document.querySelector("#unmatchedList"),
  progressPanel: document.querySelector("#progressPanel"),
  progressAnnouncement: document.querySelector("#progressAnnouncement"),
  progressElapsed: document.querySelector("#progressElapsed"),
  progressLabel: document.querySelector("#progressLabel"),
  progressValue: document.querySelector("#progressValue"),
  progressMeter: document.querySelector("#progressMeter"),
  progressMeterFill: document.querySelector("#progressMeterFill"),
  openSync: document.querySelector("#openSync"),
  openSyncFromEmpty: document.querySelector("#openSyncFromEmpty"),
  openGuide: document.querySelector("#openGuide"),
  clearData: document.querySelector("#clearData"),
  pageTitle: document.querySelector("#pageTitle"),
  pageUrl: document.querySelector("#pageUrl"),
  pageFieldMeta: document.querySelector("#pageFieldMeta"),
  resumeMeta: document.querySelector("#resumeMeta"),
  prepMeta: document.querySelector("#prepMeta"),
};

function mountPixelStarLoader() {
  const loader = document.querySelector("[data-pixel-star-loader]");
  if (!loader) return;
  const fragment = document.createDocumentFragment();
  let order = 0;
  PIXEL_STAR_PATTERN.forEach((row) => {
    [...row].forEach((cell) => {
      const dot = document.createElement("span");
      dot.className = cell === "x" ? "pixel-star-loader__dot pixel-star-loader__dot--active" : "pixel-star-loader__dot";
      if (cell === "x") dot.style.setProperty("--pixel-star-order", String(order));
      fragment.append(dot);
      order += 1;
    });
  });
  loader.replaceChildren(fragment);
}

mountPixelStarLoader();

let overwriteConfirmationExpiresAt = 0;
let overwriteConfirmationTimer = null;
let clearConfirmationExpiresAt = 0;
let clearConfirmationTimer = null;
let activeFillAbortController = null;
let progressStartedAt = 0;
let progressClockTimer = null;
let lastProgressAnnouncement = "";
let activeAiOperationId = null;

function isLocalExactFallbackField(field) {
  return Number(field?.deterministicConfidence) >= LOCAL_EXACT_MIN_CONFIDENCE
    && /^(?:basics\.(?:name|phone|email|birthDate|gender|city)|education\.(?:school|major|degree|startDate|endDate)|work\.(?:company|title|startDate|endDate)|project\.(?:name|role|startDate|endDate)|campus\.(?:title|role|date))$/.test(field?.deterministicKey || "");
}

const progressDefaults = {
  extract: "等待开始",
  match: "等待字段清单",
  fill: "等待匹配结果",
  summary: "等待填写完成",
};

function resetProgress() {
  elements.progressPanel.hidden = false;
  lastProgressAnnouncement = "";
  elements.progressAnnouncement.textContent = "";
  for (const [step, text] of Object.entries(progressDefaults)) updateProgress(step, "pending", text);
  startProgressClock();
  updateTaskProgress(0, 0, "准备读取页面");
}

async function renderPageContext() {
  if (!elements.pageTitle || !elements.pageUrl || !elements.pageFieldMeta) return;
  if (!globalThis.chrome?.tabs?.query) {
    elements.pageTitle.textContent = "校园招聘 · 产品实习生申请";
    elements.pageUrl.textContent = "careers.example.com/application/product-intern";
    elements.pageFieldMeta.textContent = "演示页面 · 点击填写后才会读取字段";
    return;
  }

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) throw new Error("missing_url");
    const pageUrl = new URL(tab.url);
    if (!/^https?:$/.test(pageUrl.protocol)) throw new Error("unsupported_page");
    elements.pageTitle.textContent = tab.title || "当前网申页面";
    elements.pageUrl.textContent = `${pageUrl.host}${pageUrl.pathname}`;
    elements.pageFieldMeta.textContent = "点击填写后才会读取字段 · 不会自动提交";
  } catch {
    elements.pageTitle.textContent = "当前页面不可用";
    elements.pageUrl.textContent = "请打开企业网申填写页面";
    elements.pageFieldMeta.textContent = "不会读取浏览器内部页面";
  }
}

function updateProgress(step, status, text) {
  const row = elements.progressPanel.querySelector(`[data-step="${step}"]`);
  if (!row) return;
  row.dataset.status = status;
  row.querySelector("p").textContent = text;
}

function startProgressClock() {
  stopProgressClock();
  progressStartedAt = Date.now();
  elements.progressElapsed.textContent = "已用时 0 秒";
  progressClockTimer = window.setInterval(() => {
    const elapsedSeconds = Math.floor((Date.now() - progressStartedAt) / 1_000);
    elements.progressElapsed.textContent = elapsedSeconds < 60
      ? `已用时 ${elapsedSeconds} 秒`
      : `已用时 ${Math.floor(elapsedSeconds / 60)} 分 ${String(elapsedSeconds % 60).padStart(2, "0")} 秒`;
  }, 1_000);
}

function stopProgressClock() {
  if (progressClockTimer) window.clearInterval(progressClockTimer);
  progressClockTimer = null;
}

function updateTaskProgress(completed, total, label) {
  const determinate = Number.isFinite(total) && total > 0;
  const safeCompleted = determinate ? Math.min(total, Math.max(0, completed)) : 0;
  const percent = determinate ? Math.round((safeCompleted / total) * 100) : null;
  elements.progressLabel.textContent = label;
  elements.progressValue.textContent = percent === null ? "处理中" : `${percent}%`;
  elements.progressMeter.dataset.mode = determinate ? "determinate" : "indeterminate";
  elements.progressMeter.setAttribute("aria-valuetext", determinate ? `已完成 ${safeCompleted} / ${total} 个处理单元` : label);
  const announcement = determinate
    ? `${label}，已完成 ${safeCompleted} / ${total} 个处理单元`
    : label;
  if (announcement !== lastProgressAnnouncement) {
    lastProgressAnnouncement = announcement;
    elements.progressAnnouncement.textContent = announcement;
  }
  if (determinate) {
    elements.progressMeter.setAttribute("aria-valuemin", "0");
    elements.progressMeter.setAttribute("aria-valuemax", "100");
    elements.progressMeter.setAttribute("aria-valuenow", String(percent));
    elements.progressMeterFill.style.transform = `scaleX(${safeCompleted / total})`;
  } else {
    elements.progressMeter.removeAttribute("aria-valuemin");
    elements.progressMeter.removeAttribute("aria-valuemax");
    elements.progressMeter.removeAttribute("aria-valuenow");
    elements.progressMeterFill.style.removeProperty("transform");
  }
}

function openPage(path) {
  void chrome.tabs.create({ url: `${STARJOB_HOME}${path}` });
}

function showResult(title, text, tone = "success", unmatchedFields = []) {
  elements.resultTitle.textContent = title;
  elements.resultText.textContent = text;
  elements.resultPanel.dataset.tone = tone;
  elements.resultPanel.hidden = false;
  const fields = [...new Set(unmatchedFields.map((field) => String(field || "").trim()).filter(Boolean))].slice(0, 8);
  elements.unmatchedList.replaceChildren(...fields.map((field) => {
    const item = document.createElement("li");
    item.textContent = field;
    return item;
  }));
  elements.unmatchedDetails.hidden = fields.length === 0;
  elements.unmatchedDetails.open = false;
}

function selectedFillMode() {
  const value = document.querySelector('input[name="fillMode"]:checked')?.value;
  return ["merge", "overwrite", "ai"].includes(value) ? value : "merge";
}

function resetOverwriteConfirmation() {
  overwriteConfirmationExpiresAt = 0;
  if (overwriteConfirmationTimer) window.clearTimeout(overwriteConfirmationTimer);
  overwriteConfirmationTimer = null;
  const mode = selectedFillMode();
  const selectedResumeLabel = elements.resumeSelect?.selectedOptions?.[0]?.textContent?.trim() || "当前简历";
  elements.modeHint.dataset.tone = mode === "overwrite" ? "warning" : mode === "ai" ? "ai" : "neutral";
  elements.modeHint.textContent = mode === "overwrite"
    ? "覆盖模式会替换页面已有内容，填写前需要再次确认。"
    : mode === "ai"
      ? "AI 只使用当前选中的「" + selectedResumeLabel + "」，会从页面顶部开始按每条记录和字段顺序逐项填写；经历描述与日期只使用对应记录。"
      : "默认只填写空白项，不会改动你已经输入的内容。";
  if (!elements.fillButton.disabled) {
    elements.fillButton.textContent = mode === "ai" ? "AI 智能填写" : mode === "overwrite" ? "覆盖已有内容" : "只填空白项";
  }
  if (elements.resultTitle.textContent === "请确认覆盖") elements.resultPanel.hidden = true;
}

function armOverwriteConfirmation() {
  overwriteConfirmationExpiresAt = Date.now() + CONFIRM_WINDOW_MS;
  elements.modeHint.dataset.tone = "warning";
  elements.modeHint.textContent = "请确认：下一次点击会覆盖当前页面已有内容。";
  elements.fillButton.textContent = "再次点击，确认覆盖并填写";
  showResult("请确认覆盖", "为了避免丢失你已经填写的内容，请再次点击上方按钮。", "warning");
  if (overwriteConfirmationTimer) window.clearTimeout(overwriteConfirmationTimer);
  overwriteConfirmationTimer = window.setTimeout(resetOverwriteConfirmation, CONFIRM_WINDOW_MS);
}

function resetClearConfirmation() {
  clearConfirmationExpiresAt = 0;
  if (clearConfirmationTimer) window.clearTimeout(clearConfirmationTimer);
  clearConfirmationTimer = null;
  elements.clearData.textContent = "清除本地数据";
  if (elements.resultTitle.textContent === "确认清除本地数据") elements.resultPanel.hidden = true;
}

function armClearConfirmation() {
  clearConfirmationExpiresAt = Date.now() + CONFIRM_WINDOW_MS;
  elements.clearData.textContent = "再次点击确认清除";
  showResult("确认清除本地数据", "这会删除扩展中已同步的所有简历，不会删除拾星网站中的云端简历。", "warning");
  if (clearConfirmationTimer) window.clearTimeout(clearConfirmationTimer);
  clearConfirmationTimer = window.setTimeout(resetClearConfirmation, CONFIRM_WINDOW_MS);
}

function formatSyncTime(value) {
  if (!value) return "简历只保存在当前浏览器";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "简历只保存在当前浏览器";
  return `上次同步 ${date.toLocaleString("zh-CN", { hour12: false })}`;
}

function formatApplicationPrep(resume) {
  const prep = resume?.applicationPrep;
  if (!prep || !Number.isFinite(prep.filledCount) || !Number.isFinite(prep.totalCount)) {
    return "可选：先在拾星完成网申前准备";
  }
  return prep.hasMinimumProfile
    ? `资料准备度 ${prep.filledCount}/${prep.totalCount} · 常见字段可带入`
    : `资料准备度 ${prep.filledCount}/${prep.totalCount} · 仍可正常填写`;
}

function friendlyFillError(error, abortReason) {
  const message = error instanceof Error ? error.message : "";
  if (error instanceof DOMException && error.name === "AbortError") {
    return abortReason === "cancelled"
      ? "本次填写已取消，页面原有内容没有改动。"
      : "AI 单批分析超过 85 秒，本次没有改动页面，请稍后重试。";
  }
  if (/cannot access|cannot read|could not establish|context invalidated|no tab with id/i.test(message)) {
    return "扩展与当前页面的连接已失效，请刷新网申页后重试。";
  }
  return /[\u3400-\u9fff]/.test(message)
    ? message
    : "当前页面暂时无法填写，请刷新网申页后重试。";
}

function throwIfAborted(signal) {
  if (signal.aborted) throw new DOMException("Aborted", "AbortError");
}

function createOperationId() {
  if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = [...bytes].map((value) => value.toString(16).padStart(2, "0"));
  return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10).join("")}`;
}

function isNarrativeField(field) {
  return /描述|介绍|评价|优势|胜任|动机|为什么|职业规划|申请原因|description|summary|profile|motivation|why|strength|career/i
    .test(`${field.label || ""} ${field.accessibleName || ""} ${field.context || ""}`);
}

function estimateFieldOutputCost(field) {
  if (isNarrativeField(field)) return 850;
  if (["textarea", "contenteditable"].includes(field.inputType)) return 360;
  if (Array.isArray(field.options) && field.options.length > 12) return 180;
  return 95;
}

function buildSemanticAiBatches(fields) {
  const batches = [];
  let current = [];
  let budget = 0;
  let groupKey = "";
  const flush = () => {
    if (current.length) batches.push(current);
    current = [];
    budget = 0;
    groupKey = "";
  };
  for (const field of fields) {
    const nextGroup = `${field.sectionType || "generic"}:${field.pageRecordId || (field.recordIndex ?? "-")}`;
    const cost = estimateFieldOutputCost(field);
    if (isNarrativeField(field)) {
      flush();
      batches.push([field]);
      continue;
    }
    if (current.length && (current.length >= AI_AUTOFILL_BATCH_FIELD_LIMIT || budget + cost > AI_AUTOFILL_BATCH_BUDGET || (groupKey && groupKey !== nextGroup && current.length >= 8))) flush();
    current.push(field);
    budget += cost;
    groupKey = groupKey || nextGroup;
  }
  flush();
  return batches;
}

async function requestAiAutofillBatch({ batch, resume, token, operationId, pageSnapshotId, batchId, taskSignal, formSections, applicationContext }) {
  const controller = new AbortController();
  const cancelFromTask = () => controller.abort(taskSignal.reason || "cancelled");
  taskSignal.addEventListener("abort", cancelFromTask, { once: true });
  const timeout = window.setTimeout(() => controller.abort("timeout"), AI_AUTOFILL_TIMEOUT_MS);
  try {
    const response = await fetch(`${STARJOB_HOME}/api/resume/extension-autofill`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ resume, fields: batch, formSections, applicationContext, operationId, pageSnapshotId, batchId }),
      cache: "no-store",
      signal: controller.signal,
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "AI 智能填写暂时不可用");
    if (payload.operationId && payload.operationId !== operationId) throw new Error("AI 操作已过期，请重新开始填写");
    if (payload.pageSnapshotId && payload.pageSnapshotId !== pageSnapshotId) throw new Error("页面已变化，请重新扫描后填写");
    if (payload.batchId && payload.batchId !== batchId) throw new Error("AI 批次已过期，请重新开始填写");
    if (payload?.diagnostics?.complete !== true) throw new Error("AI 返回内容不完整，未写入页面");
    return payload;
  } finally {
    window.clearTimeout(timeout);
    taskSignal.removeEventListener("abort", cancelFromTask);
  }
}

function summarizeFrameResults(frameResults) {
  return frameResults.map((entry) => entry.result).filter(Boolean).reduce(
    (acc, item) => ({
      scanned: acc.scanned + (item.scanned || 0),
      matched: acc.matched + (item.matched || 0),
      filled: acc.filled + (item.filled || 0),
      preserved: acc.preserved + (item.preserved || 0),
      empty: acc.empty + (item.empty || 0),
      manual: acc.manual + (item.manual || 0),
      derived: acc.derived + (item.derived || 0),
      failed: acc.failed + (item.failed || 0),
      unmatched: [...acc.unmatched, ...(Array.isArray(item.unmatched) ? item.unmatched : [])],
    }),
    { scanned: 0, matched: 0, filled: 0, preserved: 0, empty: 0, manual: 0, derived: 0, failed: 0, unmatched: [] },
  );
}

function qualifyFrameFieldKey(frameId, fieldIndex, fieldKey) {
  // Put the two uniqueness dimensions before any truncation. Long ATS paths
  // can exceed the server key limit; truncating only the tail must never erase
  // the candidate index and collapse two controls into one mapping.
  const prefix = `${frameId}::${fieldIndex}::`;
  return `${prefix}${String(fieldKey).slice(0, 520 - prefix.length)}`;
}

async function waitForFormStability(tabId, taskSignal) {
  throwIfAborted(taskSignal);
  await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: async () => new Promise((resolve) => {
      const root = document.body || document.documentElement;
      if (!root) { resolve({ quiet: true, mutations: 0 }); return; }
      let mutations = 0;
      let quietTimer;
      const finish = (quiet) => {
        observer.disconnect();
        window.clearTimeout(quietTimer);
        window.clearTimeout(maxTimer);
        resolve({ quiet, mutations });
      };
      const scheduleQuiet = () => {
        window.clearTimeout(quietTimer);
        quietTimer = window.setTimeout(() => finish(true), 320);
      };
      const observer = new MutationObserver((records) => {
        mutations += records.length;
        scheduleQuiet();
      });
      observer.observe(root, { childList: true, subtree: true, attributes: true });
      const maxTimer = window.setTimeout(() => finish(false), 2_400);
      scheduleQuiet();
    }),
  });
  throwIfAborted(taskSignal);
}

function analysisFingerprint(results) {
  return results
    .filter((entry) => entry.result)
    .sort((left, right) => left.frameId - right.frameId)
    .map((entry) => `${entry.frameId}:${(entry.result.fields || []).map((field) => [
      field.fieldKey,
      field.pageRecordId || "-",
      field.semanticKey || field.deterministicKey || "-",
    ].join("@")).join(",")}`)
    .join("|");
}

async function scanStableForm(tabId, taskSignal, maxAttempts = 3) {
  let previousFingerprint = "";
  let latestResults = [];
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    await waitForFormStability(tabId, taskSignal);
    latestResults = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: ["fill.js"],
    });
    throwIfAborted(taskSignal);
    const fingerprint = analysisFingerprint(latestResults);
    if (fingerprint && fingerprint === previousFingerprint) return latestResults;
    previousFingerprint = fingerprint;
  }
  return latestResults;
}

async function executeMappedFillByFrame({
  tabId,
  mappings,
  fieldAddressByQualifiedKey,
  storageState,
  mappingStorageKey,
  taskSignal,
  scanAttempts = 2,
}) {
  const normalizeIdentity = (value) => String(value ?? "").normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
  const fieldKind = (field) => {
    const own = normalizeIdentity(field.ownDescriptor || `${field.label || ""} ${field.accessibleName || ""} ${field.attributes || ""}`);
    if (/学校名称|毕业院校|院校名称|schoolname|universityname/.test(own)) return "education.school";
    if (/专业名称|主修专业|majorname|fieldofstudy/.test(own)) return "education.major";
    if (/学历|学位|degree|educationlevel/.test(own)) return "education.degree";
    if (/公司类型|公司性质|所在行业|行业类型|companytype|industry/.test(own)) return "work.companyType";
    if (/公司名称|单位名称|雇主名称|companyname|employername/.test(own)) return "work.company";
    if (/职位名称|岗位名称|职务名称|jobtitle|positionname/.test(own)) return "work.title";
    if (/项目名称|projectname|projecttitle/.test(own)) return "project.name";
    if (/项目角色|担任角色|projectrole/.test(own)) return "project.role";
    if (/手机号码|手机号|联系电话|mobilephone|phonenumber|telephone/.test(own)) return "basics.phone";
    if (/邮箱地址|电子邮箱|emailaddress/.test(own)) return "basics.email";
    if (/起止时间|就读时间|入学时间|毕业时间|开始时间|结束时间|日期|年月|startdate|enddate/.test(own)) return "date";
    return field.deterministicKey || (field.datePart ? "date" : "");
  };
  const identitiesCompatible = (original, candidate) => {
    const originalKind = fieldKind(original);
    const candidateKind = fieldKind(candidate);
    if (originalKind && candidateKind && originalKind !== candidateKind) {
      const bothDates = (originalKind === "date" || /\.(?:startDate|endDate|date)$/.test(originalKind))
        && (candidateKind === "date" || /\.(?:startDate|endDate|date)$/.test(candidateKind));
      if (!bothDates) return false;
    }
    if (original.pageRecordId && candidate.pageRecordId && original.pageRecordId !== candidate.pageRecordId) return false;
    return true;
  };
  await chrome.storage.local.set({
    analysisOnly: true,
    aiOnly: false,
    aiFieldMappings: {},
    aiAutofillOnly: false,
    aiValueMappings: {},
    aiTargetFieldKeys: [],
  });
  const freshResults = await scanStableForm(tabId, taskSignal, scanAttempts);
  const freshFields = freshResults.flatMap((entry) => (entry.result?.fields || []).map((field) => ({
    frameId: entry.frameId,
    rawFieldKey: field.fieldKey,
    field,
  })));
  const fieldScore = (original, candidate) => {
    const current = candidate.field;
    let score = 0;
    if (original.elementIdentity && original.elementIdentity === current.elementIdentity) score += 12;
    if (original.sourceFieldKey && original.sourceFieldKey === candidate.rawFieldKey) score += 10;
    if (original.pageRecordId && original.pageRecordId === current.pageRecordId) score += 6;
    if (original.deterministicKey && original.deterministicKey === current.deterministicKey) score += 5;
    if (original.semanticKey && original.semanticKey === current.semanticKey) score += 4;
    if (original.sectionType && original.sectionType === current.sectionType) score += 3;
    if (Number.isInteger(original.recordIndex) && original.recordIndex === current.recordIndex) score += 4;
    if ((original.recordScope || null) === (current.recordScope || null)) score += 1;
    if ((original.datePart || null) === (current.datePart || null)) score += 2;
    const originalLabel = normalizeIdentity(original.accessibleName || original.label);
    const currentLabel = normalizeIdentity(current.accessibleName || current.label);
    if (originalLabel && originalLabel === currentLabel) score += 4;
    const originalOwn = normalizeIdentity(original.ownDescriptor);
    const currentOwn = normalizeIdentity(current.ownDescriptor);
    if (originalOwn && originalOwn === currentOwn) score += 8;
    return score;
  };
  const resolveFreshAddress = (address) => {
    const exact = freshFields.filter((candidate) => candidate.frameId === address.frameId
      && candidate.rawFieldKey === address.rawFieldKey
      && identitiesCompatible(address.field, candidate.field));
    if (exact.length === 1) return exact[0];
    const ranked = freshFields
      .map((candidate) => ({ candidate, score: fieldScore(address.field, candidate) }))
      .filter((entry) => identitiesCompatible(address.field, entry.candidate.field) && entry.score >= 10)
      .sort((left, right) => right.score - left.score);
    if (!ranked.length || (ranked[1] && ranked[0].score - ranked[1].score < 2)) return null;
    return ranked[0].candidate;
  };

  const rebound = [];
  let rebindFailedFields = 0;
  for (const [qualifiedKey, mapping] of Object.entries(mappings)) {
    const address = fieldAddressByQualifiedKey.get(qualifiedKey);
    if (!address) {
      rebindFailedFields += 1;
      continue;
    }
    const freshAddress = resolveFreshAddress(address);
    if (!freshAddress) {
      rebindFailedFields += 1;
      continue;
    }
    rebound.push({ qualifiedKey, mapping, ...freshAddress });
  }

  const frameIds = [...new Set(rebound.map((entry) => entry.frameId))];
  const mappingsByFrame = new Map(frameIds.map((frameId) => [frameId, {}]));
  const rawKeysByFrame = new Map(frameIds.map((frameId) => [frameId, new Set()]));
  for (const entry of rebound) {
    const usedRawKeys = rawKeysByFrame.get(entry.frameId);
    if (!usedRawKeys || usedRawKeys.has(entry.rawFieldKey)) {
      throw new Error("字段身份发生冲突，本次未写入页面");
    }
    usedRawKeys.add(entry.rawFieldKey);
    mappingsByFrame.get(entry.frameId)[entry.rawFieldKey] = entry.mapping;
  }

  const results = [];
  let failedFrames = 0;
  let failedFields = 0;
  for (const frameId of frameIds) {
    const frameMappings = mappingsByFrame.get(frameId) || {};
    await chrome.storage.local.set({
      ...storageState,
      [mappingStorageKey]: frameMappings,
      aiTargetFieldKeys: Object.keys(frameMappings),
    });
    try {
      results.push(...await chrome.scripting.executeScript({
        target: { tabId, frameIds: [frameId] },
        files: ["fill.js"],
      }));
    } catch (error) {
      failedFrames += 1;
      failedFields += Object.keys(frameMappings).length;
      console.warn("[starjob_fill_frame_failed]", {
        frameId,
        message: error instanceof Error ? error.message : String(error),
      });
    }
  }
  return {
    results,
    failedFrames,
    failedFields: failedFields + rebindFailedFields,
    reboundFieldCount: rebound.length,
    rebindFailedFields,
  };
}

async function executeMappedFillProgressively(options) {
  throwIfAborted(options.taskSignal);
  // One AI batch is also one execution unit. Re-scan before the batch, then
  // write its small set of controls together. fill.js resolves a disconnected
  // element by its stable identity if the host framework rerenders mid-batch.
  return executeMappedFillByFrame({ ...options, scanAttempts: 1 });
}

function sanitizeResumeForAi(resume, fields) {
  const content = resume?.content || {};
  const basics = content.basics || {};
  const text = (value) => typeof value === "string" ? value : "";
  const bullets = (value) => Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
  const mapEntries = (value, mapper) => Array.isArray(value) ? value.map(mapper) : [];
  const recordRoots = new Set((Array.isArray(fields) ? fields : [])
    .map((field) => String(field?.resumePath || "").match(/^(education|work|projects|campus|awards|certifications|languages)\[(\d+)\]/))
    .filter(Boolean)
    .map((match) => `${match[1]}[${match[2]}]`));
  const recordNarrativeBatch = Array.isArray(fields) && fields.length > 0 && fields.every((field) => (
    /^(?:work|project|campus|awards)\.description$/.test(field?.deterministicKey || "")
    && recordRoots.has(String(field?.resumePath || "").replace(/\..*$/, ""))
  ));
  const visibleRecord = (collection, index) => !recordNarrativeBatch || recordRoots.has(`${collection}[${index}]`);
  const customEntry = (item = {}) => ({
    title: text(item.title),
    role: text(item.role),
    date: text(item.date),
    bullets: bullets(item.bullets),
  });
  const normalizeDescriptor = (value) => String(value ?? "").normalize("NFKC").toLowerCase().replace(/[\s\-_./\\:：,，()（）\[\]【】{}<>《》?？*]+/g, "");
  const includeBirthDate = Array.isArray(fields) && fields.some((field) => {
    const descriptor = normalizeDescriptor(`${field?.label || ""} ${field?.attributes || ""} ${field?.context || ""}`);
    const rawDescriptor = `${field?.label || ""} ${field?.attributes || ""} ${field?.context || ""}`;
    return ["出生日期", "出生年月", "生日", "birthdate", "dateofbirth", "年龄", "周岁", "age"].some((term) => descriptor.includes(normalizeDescriptor(term)))
      || /(?:^|[^a-z])dob(?:[^a-z]|$)/i.test(rawDescriptor);
  });

  return {
    title: text(resume?.title),
    targetRole: text(resume?.targetRole),
    jobTarget: text(resume?.jobTarget),
    templateId: text(resume?.templateId),
    content: {
      basics: {
        name: text(basics.name),
        englishName: text(basics.englishName),
        birthDate: includeBirthDate ? text(basics.birthDate) : "",
        gender: text(basics.gender),
        nationality: text(basics.nationality),
        preferredLocations: text(basics.preferredLocations),
        phone: text(basics.phone),
        email: text(basics.email),
        city: text(basics.city),
        linkedin: text(basics.linkedin),
        github: text(basics.github),
        website: text(basics.website),
        targetRole: text(basics.targetRole),
      },
      education: mapEntries(content.education, (item = {}, index) => visibleRecord("education", index) ? ({
        school: text(item.school), degree: text(item.degree), major: text(item.major),
        startDate: text(item.startDate), endDate: text(item.endDate), gpa: text(item.gpa),
        courses: text(item.courses), honors: text(item.honors),
      }) : ({})),
      work: mapEntries(content.work, (item = {}, index) => visibleRecord("work", index) ? ({
        experienceType: ["internship", "employment", "other"].includes(item.experienceType) ? item.experienceType : "other",
        company: text(item.company), title: text(item.title), location: text(item.location),
        startDate: text(item.startDate), endDate: text(item.endDate), current: item.current === true,
        bullets: bullets(item.bullets),
      }) : ({ experienceType: ["internship", "employment", "other"].includes(item.experienceType) ? item.experienceType : "other" })),
      projects: mapEntries(content.projects, (item = {}, index) => visibleRecord("projects", index) ? ({
        name: text(item.name), role: text(item.role), url: text(item.url), startDate: text(item.startDate),
        endDate: text(item.endDate), bullets: bullets(item.bullets), keywords: text(item.keywords),
      }) : ({})),
      skills: recordNarrativeBatch ? [] : mapEntries(content.skills, (item = {}) => ({
        category: text(item.category),
        skills: Array.isArray(item.skills) ? item.skills.filter((skill) => typeof skill === "string") : [],
      })),
      campus: mapEntries(content.campus, (item, index) => visibleRecord("campus", index) ? customEntry(item) : {}),
      awards: mapEntries(content.awards, (item, index) => visibleRecord("awards", index) ? customEntry(item) : {}),
      certifications: mapEntries(content.certifications, (item, index) => visibleRecord("certifications", index) ? customEntry(item) : {}),
      languages: mapEntries(content.languages, (item, index) => visibleRecord("languages", index) ? customEntry(item) : {}),
      customSections: recordNarrativeBatch ? [] : mapEntries(content.customSections, customEntry),
    },
  };
}

async function render() {
  const stored = await chrome.storage.local.get(STORAGE_KEYS);
  const resumes = Array.isArray(stored.starjobResumes) ? stored.starjobResumes : [];
  const activeId = resumes.some((resume) => resume.id === stored.activeResumeId)
    ? stored.activeResumeId
    : resumes[0]?.id;

  elements.emptyState.hidden = resumes.length > 0;
  elements.readyState.hidden = resumes.length === 0;
  elements.resultPanel.hidden = true;
  elements.progressPanel.hidden = true;
  elements.resumeSelect.replaceChildren();

  for (const resume of resumes) {
    const option = document.createElement("option");
    option.value = resume.id;
    option.textContent = resume.targetRole
      ? `${resume.title || "未命名简历"} - ${resume.targetRole}`
      : resume.title || "未命名简历";
    option.selected = resume.id === activeId;
    elements.resumeSelect.append(option);
  }

  const selectedResume = resumes.find((resume) => resume.id === activeId) || resumes[0];
  elements.resumeMeta.textContent = resumes.length > 1
    ? `${selectedResume?.title || "未命名简历"} · ${resumes.length} 份已同步`
    : `${selectedResume?.title || "未命名简历"} · 已同步`;
  elements.prepMeta.textContent = formatApplicationPrep(selectedResume);

  const selectedMode = ["merge", "overwrite", "ai"].includes(stored.fillMode) ? stored.fillMode : "merge";
  document.querySelector(`input[name="fillMode"][value="${selectedMode}"]`).checked = true;
  elements.syncMeta.textContent = formatSyncTime(stored.lastSyncedAt);
  resetOverwriteConfirmation();
  resetClearConfirmation();
  await renderPageContext();
}

async function fillCurrentPage() {
  const fillMode = selectedFillMode();
  if (fillMode === "overwrite" && overwriteConfirmationExpiresAt < Date.now()) {
    armOverwriteConfirmation();
    return;
  }
  resetOverwriteConfirmation();
  if (!globalThis.chrome?.tabs?.query || !globalThis.chrome?.scripting?.executeScript || !globalThis.chrome?.storage?.local) {
    showResult("请从浏览器工具栏打开扩展", "当前是界面预览，实际填写需要在 Chrome 或 Edge 的扩展菜单中打开拾星网申助手。", "warning");
    return;
  }
  const taskController = new AbortController();
  let taskOperationId = null;
  let progressiveFilledOnPage = 0;
  activeFillAbortController = taskController;
  elements.fillButton.disabled = fillMode !== "ai";
  elements.fillButton.textContent = fillMode === "ai" ? "停止本次智能填写" : "正在逐项分析";
  elements.resultPanel.hidden = true;
  resetProgress();
  updateProgress("extract", "loading", "正在读取可见表单字段");

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab.url || /^(chrome|edge|about|chrome-extension):/.test(tab.url)) {
      throw new Error("当前页面不允许扩展填写，请打开企业网申页面后重试。");
    }

    const activeResumeId = elements.resumeSelect.value;
    await chrome.storage.local.set({
      activeResumeId,
      fillMode,
      analysisOnly: true,
      aiOnly: false,
      aiFieldMappings: {},
      aiAutofillOnly: false,
      aiValueMappings: {},
    });

    const analysisResults = await scanStableForm(tab.id, taskController.signal);
    throwIfAborted(taskController.signal);
    const analyses = analysisResults
      .filter((entry) => entry.result)
      .map((entry) => ({ frameId: entry.frameId, result: entry.result }));
    const fields = analyses.flatMap(({ frameId, result }) => (
      Array.isArray(result.fields)
        ? result.fields.map((field, fieldIndex) => ({
            ...field,
            fieldKey: qualifyFrameFieldKey(frameId, fieldIndex, field.fieldKey),
            sourceFieldKey: field.fieldKey,
            sourceFrameId: frameId,
          }))
        : []
    ));
    const formSections = analyses.flatMap(({ frameId, result }) => (
      Array.isArray(result.formSections)
        ? (() => {
            const indexByKey = new Map((Array.isArray(result.fields) ? result.fields : []).map((field, index) => [field.fieldKey, index]));
            return result.formSections.map((section) => ({
              ...section,
              fieldKeys: Array.isArray(section.fieldKeys)
                ? section.fieldKeys.map((rawKey) => qualifyFrameFieldKey(frameId, indexByKey.get(rawKey) ?? 0, rawKey))
                : [],
            }));
          })()
        : []
    ));
    const fieldAddressByQualifiedKey = new Map(fields.map((field) => [field.fieldKey, {
      frameId: field.sourceFrameId,
      rawFieldKey: field.sourceFieldKey,
      field,
    }]));
    const extracted = analyses.reduce((sum, entry) => sum + (entry.result.scanned || 0), 0);
    const locallyIdentified = analyses.reduce((sum, entry) => sum + (entry.result.identified || 0), 0);
    const smartMatchFields = fields
      .filter((field) => !field.deterministicKey || Number(field.deterministicConfidence) < 0.74)
      .slice(0, SMART_MATCH_MAX_FIELDS);
    updateProgress("extract", "success", `共提取 ${extracted} 个可见字段`);
    console.info("[starjob_pipeline_checkpoint_A]", {
      scanFieldCount: extracted,
      eligibleFieldCount: fields.length,
      frames: analyses.map(({ frameId, result }) => ({ frameId, diagnostics: result.pipelineDiagnostics, fieldTraces: result.fieldTraces })),
    });
    updateTaskProgress(1, 4, `已读取 ${extracted} 个可见字段`);

    if (extracted === 0) {
      updateProgress("match", "fallback", "当前页面没有可分析字段");
      updateProgress("fill", "fallback", "当前页面没有可填写字段");
      updateProgress("summary", "success", "请进入具体网申表单后重试");
      showResult("没有找到可填写表单", "请进入网申填写页后重试。部分验证码或封闭组件需要手动处理。", "error");
      return;
    }

    if (fillMode === "ai" && fields.length > AI_AUTOFILL_MAX_FIELDS) {
      const limitMessage = `检测到 ${fields.length} 个安全字段，单页上限为 ${AI_AUTOFILL_MAX_FIELDS} 个`;
      updateProgress("match", "fallback", `${limitMessage}，未调用 AI`);
      updateProgress("fill", "fallback", "本次没有写入页面");
      updateProgress("summary", "fallback", "请分步骤填写或收起部分表单区块后重试");
      updateTaskProgress(1, 4, `${limitMessage}，本次已停止`);
      showResult(
        "表单字段过多，未开始填写",
        `${limitMessage}。本次未调用 AI，也没有改动页面。请分步骤填写或收起部分表单区块后重试。`,
        "error",
      );
      return;
    }

    if (fillMode === "ai") {
      updateProgress("match", "loading", `正在让 AI 从上到下处理 ${fields.length} 个安全字段`);
      const stored = await chrome.storage.local.get(["starjobResumes", "matchToken", "matchTokenExpiresAt", "aiMatchingAvailable"]);
      const selectedResume = (Array.isArray(stored.starjobResumes) ? stored.starjobResumes : [])
        .find((resume) => resume.id === activeResumeId);
      const tokenValid = stored.matchToken
        && (!stored.matchTokenExpiresAt || new Date(stored.matchTokenExpiresAt).getTime() > Date.now());
      if (!selectedResume?.content) throw new Error("没有找到所选简历，请重新同步后再试。");
      if (!stored.aiMatchingAvailable || !tokenValid) throw new Error("AI 智能填写需要重新同步简历，请返回拾星同步后再试。");

      const aiValueMappings = {};
      let acceptedMappings = 0;
      let localExactFallbacks = 0;
      let aiRawMappingCount = 0;
      let validatedMappingCount = 0;
      const pageUrl = new URL(tab.url);
      const extractedApplicationContext = analyses.find((entry) => entry.result?.applicationContext)?.result?.applicationContext || {};
      const applicationContext = {
        ...extractedApplicationContext,
        company: extractedApplicationContext.company || analyses[0]?.result?.provider?.company || pageUrl.hostname.replace(/^www\./, ""),
        jobTitle: extractedApplicationContext.jobTitle || tab.title || "",
        sourceUrl: `${pageUrl.origin}${pageUrl.pathname}`,
        provider: analyses[0]?.result?.provider?.provider || "generic",
        providerConfidence: analyses[0]?.result?.provider?.confidence || 0,
      };
      await chrome.storage.local.set({ starjobApplicationSession: { ...applicationContext, capturedAt: new Date().toISOString() } });
      const batches = buildSemanticAiBatches(fields);
      if (batches.length > AI_AUTOFILL_MAX_BATCHES) {
        throw new Error(`当前页面需要拆分为 ${batches.length} 个 AI 批次，超过安全上限。请分步骤填写或收起部分表单区块后重试。`);
      }
      const totalTaskUnits = batches.length + 3;
      const operationId = createOperationId();
      taskOperationId = operationId;
      const pageSnapshotId = createOperationId();
      activeAiOperationId = operationId;
      const sectionsForBatch = (batch) => {
        const keys = new Set(batch.map((field) => field.fieldKey));
        return formSections.map((section) => ({
          ...section,
          fieldKeys: (section.fieldKeys || []).filter((fieldKey) => keys.has(fieldKey)),
        })).filter((section) => section.fieldKeys.length > 0);
      };
      updateTaskProgress(1, totalTaskUnits, `已按表单结构拆分为 ${batches.length} 批，正在依次分析`);
      let completedBatches = 0;
      const progressiveResults = [];
      let progressiveFailedFrames = 0;
      let progressiveFailedFields = 0;
      let progressiveReboundFields = 0;
      let progressiveRebindFailures = 0;
      const acceptPayload = (payload, batch) => {
        const batchMappings = {};
        aiRawMappingCount += Number(payload?.diagnostics?.aiRawMappingCount || 0);
        validatedMappingCount += Number(payload?.diagnostics?.validatedMappingCount || 0);
        for (const mapping of payload.mappings || []) {
          if (mapping?.fieldKey && typeof mapping.value === "string" && mapping.value.trim()
            && !["manual", "skip"].includes(mapping.action)
            && ["resume", "exact_fact", "normalized_fact", "derived", "semantic_inference", "grounded_generation", "user_preference"].includes(mapping.basis) && Number(mapping.confidence) >= AI_AUTOFILL_MIN_CONFIDENCE) {
            const compiled = {
              value: mapping.value.trim(),
              displayValue: typeof mapping.displayValue === "string" ? mapping.displayValue.trim() : null,
              confidence: Number(mapping.confidence),
              basis: mapping.basis,
              action: mapping.action || "fill",
              evidence: Array.isArray(mapping.evidence) ? mapping.evidence : [],
              source: mapping.source || null,
              needsReview: mapping.needsReview === true,
              controlType: mapping.controlType || null,
              optionMatch: mapping.optionMatch || null,
            };
            aiValueMappings[mapping.fieldKey] = compiled;
            batchMappings[mapping.fieldKey] = compiled;
            acceptedMappings += 1;
          }
        }
        // For hard resume facts the model is advisory. If it omits or marks a
        // high-confidence field as manual, send the field to fill.js anyway.
        // fill.js resolves the value from the selected resume and refuses the
        // write if the freshly scanned field no longer has an exact match.
        for (const field of batch) {
          if (batchMappings[field.fieldKey] || !isLocalExactFallbackField(field)) continue;
          const compiled = {
            value: null,
            displayValue: null,
            confidence: 0.99,
            basis: "exact_fact",
            action: field.interactionType?.includes("select") ? "select" : "fill",
            evidence: field.resumePath ? [field.resumePath] : [],
            source: field.resumePath ? { type: "resume", path: field.resumePath } : null,
            needsReview: false,
            controlType: field.controlType || null,
            optionMatch: null,
            localExactOnly: true,
          };
          aiValueMappings[field.fieldKey] = compiled;
          batchMappings[field.fieldKey] = compiled;
          localExactFallbacks += 1;
        }
        return batchMappings;
      };
      for (let index = 0; index < batches.length; index += 1) {
        const batch = batches[index];
        throwIfAborted(taskController.signal);
        if (activeAiOperationId !== operationId) throw new DOMException("Stale operation", "AbortError");
        const batchId = createOperationId();
        const payload = await requestAiAutofillBatch({
          batch,
          resume: sanitizeResumeForAi(selectedResume, batch),
          token: stored.matchToken,
          operationId,
          pageSnapshotId,
          batchId,
          taskSignal: taskController.signal,
          formSections: sectionsForBatch(batch),
          applicationContext,
        });
        if (activeAiOperationId !== operationId) throw new DOMException("Stale operation", "AbortError");
        const batchMappings = acceptPayload(payload, batch);
        updateProgress("match", "loading", `第 ${index + 1}/${batches.length} 批分析完成，正在写入并回读`);
        if (Object.keys(batchMappings).length) {
          const batchFill = await executeMappedFillProgressively({
            tabId: tab.id,
            mappings: batchMappings,
            fieldAddressByQualifiedKey,
            mappingStorageKey: "aiValueMappings",
            taskSignal: taskController.signal,
            storageState: {
              analysisOnly: false,
              aiOnly: false,
              aiFieldMappings: {},
              aiAutofillOnly: true,
            },
          });
          progressiveResults.push(...batchFill.results);
          progressiveFailedFrames += batchFill.failedFrames;
          progressiveFailedFields += batchFill.failedFields;
          progressiveReboundFields += batchFill.reboundFieldCount;
          progressiveRebindFailures += batchFill.rebindFailedFields;
        }
        completedBatches += 1;
        const runningTotal = summarizeFrameResults(progressiveResults);
        progressiveFilledOnPage = runningTotal.filled;
        updateProgress("fill", "loading", `已完成 ${completedBatches}/${batches.length} 批，当前写入 ${runningTotal.filled} 项`);
        updateTaskProgress(1 + completedBatches, totalTaskUnits, `第 ${completedBatches}/${batches.length} 批已分析、写入并回读`);
      }
      console.info("[starjob_pipeline_checkpoint_B_C]", {
        operationId,
        pageSnapshotId,
        batchCount: batches.length,
        aiPayloadFieldCount: fields.length,
        aiRawMappingCount,
        validatedMappingCount,
        compiledActionCount: Object.keys(aiValueMappings).length,
        localExactFallbackCount: localExactFallbacks,
        missingDeterministicFieldCount: fields.filter((field) => isLocalExactFallbackField(field) && !aiValueMappings[field.fieldKey]).length,
      });
      updateProgress("match", "success", `${completedBatches} 批均已分析并写入，取得 ${acceptedMappings} 个 AI 答案${localExactFallbacks ? `，并补上 ${localExactFallbacks} 个简历确定值` : ""}`);
      updateProgress("fill", "loading", "正在汇总每批写入回读结果");
      updateTaskProgress(2 + batches.length, totalTaskUnits, `正在汇总 ${acceptedMappings} 个可用值`);
      throwIfAborted(taskController.signal);
      activeFillAbortController = null;
      const total = summarizeFrameResults(progressiveResults);
      console.info("[starjob_pipeline_checkpoint_D]", {
        ...total,
        reboundFieldCount: progressiveReboundFields,
        rebindFailedFields: progressiveRebindFailures,
        frames: progressiveResults.map(({ frameId, result }) => ({ frameId, diagnostics: result?.pipelineDiagnostics, fieldTraces: result?.fieldTraces })),
      });
      total.failed += progressiveFailedFields;
      total.manual = Math.max(0, fields.length - total.filled - total.preserved);
      total.unmatched = [...new Set(total.unmatched)];
      const frameFailureCopy = progressiveFailedFrames > 0 ? `（涉及 ${progressiveFailedFrames} 个页面区域）` : "";
      updateProgress("fill", total.failed > 0 ? "fallback" : "success", `已填写 ${total.filled} 项，其中 ${total.derived} 项为 AI 派生${total.failed > 0 ? `，${total.failed} 项写入失败${frameFailureCopy}` : ""}`);
      updateProgress("summary", total.failed > 0 ? "fallback" : "success", `保留已有内容 ${total.preserved} 项，${total.manual} 项需手动确认${total.failed > 0 ? `，其中 ${total.failed} 项写入失败` : ""}`);
      updateTaskProgress(totalTaskUnits, totalTaskUnits, `已填写 ${total.filled} 项，${total.manual} 项需手动确认${total.failed > 0 ? `，${total.failed} 项写入失败` : ""}`);
      showResult(
        total.failed > 0 ? `AI 已填写 ${total.filled} 项，部分未完成` : `AI 已填写 ${total.filled} 项`,
        `已按简历从上到下处理；无明确依据的内容保持空白。其中 ${total.derived} 项为格式、选项或自我描述等派生值，已用琥珀色边框标记。${total.failed > 0 ? `需手动确认的内容中，有 ${total.failed} 项因页面控件或页面区域异常写入失败${frameFailureCopy}。` : ""}`,
        total.failed > 0 ? "warning" : "success",
        total.unmatched,
      );
      return;
    }

    updateProgress("match", "success", `本地规则已识别 ${locallyIdentified} 个`);
    updateProgress("fill", "loading", "正在按经历卡片立即填写");
    await chrome.storage.local.set({ analysisOnly: false, aiOnly: false, aiFieldMappings: {}, aiAutofillOnly: false, aiValueMappings: {} });
    const localFrameResults = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ["fill.js"],
    });
    throwIfAborted(taskController.signal);
    const total = summarizeFrameResults(localFrameResults);
    updateProgress("fill", "success", `本地填写完成 ${total.filled}/${total.matched || total.scanned}`);
    updateTaskProgress(2, 4, `本地规则已填写 ${total.filled} 项`);

    if (total.scanned === 0) {
      updateProgress("fill", "fallback", "当前页面没有可填写字段");
      updateProgress("summary", "success", "请进入具体网申表单后重试");
      showResult("没有找到可填写表单", "请进入网申填写页后重试。部分验证码或封闭组件需要手动处理。", "error");
      return;
    }

    const stored = await chrome.storage.local.get(["matchToken", "matchTokenExpiresAt", "aiMatchingAvailable"]);
    let aiMappings = {};
    let aiMatched = 0;
    const tokenValid = stored.matchToken
      && (!stored.matchTokenExpiresAt || new Date(stored.matchTokenExpiresAt).getTime() > Date.now());

    if (smartMatchFields.length && stored.aiMatchingAvailable && tokenValid) {
      updateProgress("match", "loading", `页面已先填，后台复核 ${smartMatchFields.length} 个未识别字段`);
      try {
        const controller = new AbortController();
        const timeout = window.setTimeout(() => controller.abort(), SMART_MATCH_TIMEOUT_MS);
        let response;
        try {
          response = await fetch(`${STARJOB_HOME}/api/resume/extension-match`, {
            method: "POST",
            headers: { Authorization: `Bearer ${stored.matchToken}`, "Content-Type": "application/json" },
            body: JSON.stringify({ fields: smartMatchFields }),
            cache: "no-store",
            signal: controller.signal,
          });
        } finally {
          window.clearTimeout(timeout);
        }
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "智能分析暂时不可用");
        for (const mapping of payload.mappings || []) {
          if (mapping?.fieldKey && mapping.key && Number(mapping.confidence) >= 0.78) {
            aiMappings[mapping.fieldKey] = { key: mapping.key, confidence: Number(mapping.confidence) };
            aiMatched += 1;
          }
        }
        if (aiMatched > 0) {
          const aiFill = await executeMappedFillByFrame({
            tabId: tab.id,
            mappings: aiMappings,
            fieldAddressByQualifiedKey,
            mappingStorageKey: "aiFieldMappings",
            taskSignal: taskController.signal,
            storageState: {
              analysisOnly: false,
              aiOnly: true,
              aiAutofillOnly: false,
              aiValueMappings: {},
            },
          });
          const aiTotal = summarizeFrameResults(aiFill.results);
          aiTotal.failed += aiFill.failedFields;
          total.filled += aiTotal.filled;
          total.matched += aiTotal.matched;
          total.empty += aiTotal.empty;
          total.failed += aiTotal.failed;
          total.manual = Math.max(0, total.manual - aiTotal.filled);
          total.unmatched.push(...aiTotal.unmatched);
        }
        updateProgress("match", "success", `本地识别 ${locallyIdentified} 个，智能复核 ${aiMatched} 个`);
        updateTaskProgress(3, 4, `本地识别 ${locallyIdentified} 个，后台复核 ${aiMatched} 个`);
      } catch (error) {
        const message = error instanceof DOMException && error.name === "AbortError"
          ? "智能复核超过 9 秒"
          : error instanceof Error ? error.message : "智能分析不可用";
        updateProgress("match", "fallback", `${message}，立即使用本地规则`);
        updateTaskProgress(3, 4, `${message}，已回退到本地规则`);
      }
    } else {
      const reason = !smartMatchFields.length
        ? "低置信字段为 0，本次无需智能复核"
        : !tokenValid ? "请重新同步简历以启用智能分析" : "本次使用本地规则匹配";
      updateProgress("match", "fallback", `${reason}，已识别 ${locallyIdentified} 个`);
      updateTaskProgress(3, 4, `${reason}，继续整理待确认项`);
    }

    updateProgress("fill", total.failed > 0 ? "fallback" : "success", `填写完成 ${total.filled}/${total.matched || total.scanned}${total.failed > 0 ? `，${total.failed} 项写入失败` : ""}`);
    updateProgress("summary", total.failed > 0 ? "fallback" : "success", `共 ${total.manual} 个需手动确认，其中 ${total.empty || 0} 个在简历中没有对应值`);
    updateTaskProgress(4, 4, `已填写 ${total.filled} 项，${total.manual} 项需手动确认${total.failed > 0 ? `，${total.failed} 项写入失败` : ""}`);
    showResult(
      total.failed > 0 ? `已填写 ${total.filled} 项，部分未完成` : `已填写 ${total.filled} 项`,
      `保留已有内容 ${total.preserved} 项，仍有 ${total.manual} 项需要你确认。${total.failed > 0 ? `其中 ${total.failed} 项因页面控件异常写入失败。` : ""}提交前请逐项检查。`,
      total.failed > 0 ? "warning" : "success",
      total.unmatched,
    );
  } catch (error) {
    console.error("[starjob_fill_failed]", {
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : null,
      operationId: taskOperationId,
      progressiveFilledOnPage,
    });
    updateProgress("summary", "fallback", "填写中断，请查看下方原因");
    const partialWriteCopy = progressiveFilledOnPage > 0 ? `此前 ${progressiveFilledOnPage} 项已经写入并通过回读，可直接保留或手动修改。` : "";
    showResult(taskController.signal.reason === "cancelled" ? "本次填写已取消" : "本次填写未完成", `${friendlyFillError(error, taskController.signal.reason)}${partialWriteCopy}`, taskController.signal.reason === "cancelled" ? "warning" : "error");
  } finally {
    await chrome.storage.local.remove(["analysisOnly", "aiOnly", "aiFieldMappings", "aiAutofillOnly", "aiValueMappings", "aiTargetFieldKeys"]);
    stopProgressClock();
    if (activeFillAbortController === taskController) activeFillAbortController = null;
    if (taskOperationId && activeAiOperationId === taskOperationId) activeAiOperationId = null;
    elements.fillButton.disabled = false;
    resetOverwriteConfirmation();
  }
}

elements.resumeSelect.addEventListener("change", () => {
  resetOverwriteConfirmation();
  void chrome.storage.local.set({ activeResumeId: elements.resumeSelect.value });
});

document.querySelectorAll('input[name="fillMode"]').forEach((input) => {
  input.addEventListener("change", () => {
    if (input.checked) {
      resetOverwriteConfirmation();
      void chrome.storage.local.set({ fillMode: input.value });
    }
  });
});

elements.fillButton.addEventListener("click", () => {
  if (activeFillAbortController) {
    activeFillAbortController.abort("cancelled");
    elements.fillButton.disabled = true;
    elements.fillButton.textContent = "正在停止，不会改动页面";
    return;
  }
  void fillCurrentPage();
});
elements.openSync.addEventListener("click", () => openPage("/extension#sync"));
elements.openSyncFromEmpty.addEventListener("click", () => openPage("/extension#sync"));
elements.openGuide.addEventListener("click", () => openPage("/extension/guide"));
elements.clearData.addEventListener("click", async () => {
  if (!globalThis.chrome?.storage?.local) return;
  if (clearConfirmationExpiresAt < Date.now()) {
    armClearConfirmation();
    return;
  }
  resetClearConfirmation();
  await chrome.storage.local.remove(STORAGE_KEYS);
  await render();
  showResult("本地数据已清除", "扩展中保存的拾星简历已删除。", "success");
});

function renderPreview() {
  elements.emptyState.hidden = true;
  elements.readyState.hidden = false;
  elements.resultPanel.hidden = true;
  elements.progressPanel.hidden = true;
  const option = document.createElement("option");
  option.value = "preview";
  option.textContent = "产品运营-校招版";
  elements.resumeSelect.append(option);
  elements.resumeMeta.textContent = "演示简历 · 63 个字段已就绪";
  elements.prepMeta.textContent = "资料准备度 7/9 · 可选补充，不影响填写";
  elements.syncMeta.textContent = "简历只保存在当前浏览器";
  document.querySelector('input[name="fillMode"][value="merge"]').checked = true;
  resetOverwriteConfirmation();
  void renderPageContext();
}

if (globalThis.chrome?.storage?.local) void render();
else renderPreview();
